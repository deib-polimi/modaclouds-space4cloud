#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

DOCKER_EXISTS=`which docker | grep "/"`
if [ -n ${DOCKER_EXISTS+x} ]; then
    if [[ $DISPLAY ]]; then
        zenity --question --text="Docker is not installed.\nDo you want to install it now?" --title "MODAClouds DesignTime"
        INSTALL_IT=$?
    else
        dialog --title "MODAClouds DesignTime" --yesno "Docker is not installed.\nDo you want to install it now?" 8 65
        INSTALL_IT=$?
    fi
    if [ $INSTALL_IT -eq 0 ]; then
        APT_GET_EXISTS=`which apt-get | grep "/"`
        PACMAN_EXISTS=`which pacman | grep "/"`
        INSTALLED=false
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y curl
            curl -sSL https://get.docker.com/ | sh
            INSTALLED=true
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S docker
            INSTALLED=true
        else
            echo "We don't support this operating system at the moment. Please install docker by yourself before running the app."
        fi
        if [ $INSTALLED = true ]; then
            sudo usermod -aG docker `whoami`
            echo "Please logout and login again to use docker without sudo."
        fi
    else
        echo "Please install docker by yourself before running the app."
    fi
fi

mkdir -p ~/.local/share/applications/
mkdir -p ~/.local/share/icons/hicolor/128x128/apps/
mkdir -p ~/.local/share/icons/hicolor/64x64/apps/
mkdir -p ~/.local/share/icons/hicolor/48x48/apps/
mkdir -p ~/.local/share/icons/hicolor/32x32/apps/
mkdir -p ~/.local/share/icons/hicolor/16x16/apps/

cp "$DESKTOP" ~/.local/share/applications/
cp $BASH ~/.local/share/applications/
cp $ICON ~/.local/share/icons/hicolor/128x128/apps/
cp $ICON ~/.local/share/icons/hicolor/64x64/apps/
cp $ICON ~/.local/share/icons/hicolor/48x48/apps/
cp $ICON ~/.local/share/icons/hicolor/32x32/apps/
cp $ICON ~/.local/share/icons/hicolor/16x16/apps/
ln -s "$HOME/.local/share/applications/$DESKTOP" `xdg-user-dir DESKTOP`

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

echo "MODAClouds DesignTime installed!"
