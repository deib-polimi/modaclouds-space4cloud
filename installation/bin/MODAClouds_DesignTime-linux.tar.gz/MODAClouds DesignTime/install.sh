#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

XDG_EXISTS=`which xdg-user-dir | grep "/"`
if [ -z "$XDG_EXISTS" ]; then
    APT_GET_EXISTS=`which apt-get | grep "/"`
    PACMAN_EXISTS=`which pacman | grep "/"`
    if [ -n "$APT_GET_EXISTS" ]; then
        sudo apt-get update
        sudo apt-get install -y xdg-user-dirs
        DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
    elif [ -n "$PACMAN_EXISTS" ]; then
        sudo pacman -Sy
        sudo pacman -S xdg-user-dirs
        DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
    else
        DESKTOP_FOLDER="$HOME/Desktop/"
    fi
else
    DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
fi
if [ ! -d "$DESKTOP_FOLDER" ]; then
    DESKTOP_FOLDER=$HOME
fi

mkdir -p ~/.local/share/applications/
mkdir -p ~/.local/share/icons/hicolor/128x128/apps/
mkdir -p ~/.local/share/icons/hicolor/64x64/apps/
mkdir -p ~/.local/share/icons/hicolor/48x48/apps/
mkdir -p ~/.local/share/icons/hicolor/32x32/apps/
mkdir -p ~/.local/share/icons/hicolor/16x16/apps/

cp "$DESKTOP" ~/.local/share/applications/
cp $BASH ~/.local/share/applications/
cp $ICON ~/.local/share/icons/hicolor/128x128/apps/
cp $ICON ~/.local/share/icons/hicolor/64x64/apps/
cp $ICON ~/.local/share/icons/hicolor/48x48/apps/
cp $ICON ~/.local/share/icons/hicolor/32x32/apps/
cp $ICON ~/.local/share/icons/hicolor/16x16/apps/
ln -s "$HOME/.local/share/applications/$DESKTOP" $DESKTOP_FOLDER

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

echo "MODAClouds DesignTime installed!"
