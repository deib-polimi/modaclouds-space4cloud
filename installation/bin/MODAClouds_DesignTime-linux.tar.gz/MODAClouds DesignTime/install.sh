#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

mkdir -p ~/.local/share/applications/
mkdir -p ~/.local/share/icons/hicolor/128x128/apps/
mkdir -p ~/.local/share/icons/hicolor/64x64/apps/
mkdir -p ~/.local/share/icons/hicolor/48x48/apps/
mkdir -p ~/.local/share/icons/hicolor/32x32/apps/
mkdir -p ~/.local/share/icons/hicolor/16x16/apps/

cp "$DESKTOP" ~/.local/share/applications/
cp $BASH ~/.local/share/applications/
cp $ICON ~/.local/share/icons/hicolor/128x128/apps/
cp $ICON ~/.local/share/icons/hicolor/64x64/apps/
cp $ICON ~/.local/share/icons/hicolor/48x48/apps/
cp $ICON ~/.local/share/icons/hicolor/32x32/apps/
cp $ICON ~/.local/share/icons/hicolor/16x16/apps/
ln -s "$HOME/.local/share/applications/$DESKTOP" `xdg-user-dir DESKTOP`

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

echo "MODAClouds DesignTime installed!"
