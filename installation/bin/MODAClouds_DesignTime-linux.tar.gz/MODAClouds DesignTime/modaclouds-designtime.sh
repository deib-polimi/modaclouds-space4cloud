#!/bin/sh

FOLDER_S4C="$1"
FOLDER_MODELIO="$2"
GEOMETRY="$3"
VNC_PORT="$4"
RDP_PORT="$5"

NAME="designtime"

DOCKER_EXISTS=`which docker | grep "/"`
VNCVIEWER_EXISTS=`which vncviewer | grep "/"`

APT_GET_EXISTS=`which apt-get | grep "/"`
PACMAN_EXISTS=`which pacman | grep "/"`

UNKNOWN_OS=100
EXEC_NOT_FOUND=200
FOLDER_NOT_SPECIFIED=300

if [ $DISPLAY ]; then
    ASKER_EXISTS=`which zenity | grep "/"`
    if [ -z "$ASKER_EXISTS" ]; then
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y zenity
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S zenity
        else
            echo "We don't support this operating system at the moment. Please install zenity by yourself."
            exit $UNKNOWN_OS
        fi
    fi
else
    ASKER_EXISTS=`which dialog | grep "/"`
    if [ -z "$ASKER_EXISTS" ]; then
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y dialog
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S dialog
        else
            echo "We don't support this operating system at the moment. Please install dialog by yourself."
            exit $UNKNOWN_OS
        fi
    fi
fi

if [ -z "$DOCKER_EXISTS" ]; then
    if [ $DISPLAY ]; then
        zenity --question --text="Docker is not installed.\nDo you want to install it now?" --title "MODAClouds DesignTime"
        INSTALL_IT=$?
    else
        dialog --title "MODAClouds DesignTime" --yesno "Docker is not installed.\nDo you want to install it now?" 8 65
        INSTALL_IT=$?
    fi
    if [ $INSTALL_IT -eq 0 ]; then
        INSTALLED=false
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y curl
            curl -sSL https://get.docker.com/ | sh
            INSTALLED=true
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S docker
            INSTALLED=true
        else
            echo "We don't support this operating system at the moment. Please install docker by yourself before running the app."
            exit $UNKNOWN_OS
        fi
        if [ $INSTALLED = true ]; then
            sudo usermod -aG docker `whoami`
            echo "Please logout and login again to use docker without sudo. Reopen the app after that."
            exit
        fi
    else
        echo "Please install docker by yourself before running the app."
        exit $EXEC_NOT_FOUND
    fi
fi

IP="localhost"

START=true
RUNNING=`docker ps | awk '{print $NF}' | grep $NAME`

if [ -n "$RUNNING" ]; then
    if [ $DISPLAY ]; then
        RESTART=`zenity --list \
                    --text "The container is already running.\nDo you want to restart it first, or you want to stop it?" \
                    --column="Choose" --column="Action" \
                    "Restart" "Restart" \
                    "Connect" "Connect" \
                    "Stop" "Stop" \
                    --title "MODAClouds DesignTime" --radiolist --cancel-label "Exit"`
    else
        RESTART=`dialog --title "MODAClouds DesignTime" --cancel-label "Exit" --radiolist \
                    "The container is already running.\nDo you want to restart it first, or you want to stop it?" 20 65 3 \
                    "Restart" "" ON \
                    "Connect" "" OFF \
                    "Stop" "" OFF 3>&1 1>&2 2>&3`
    fi

    if [ "$RESTART" = "Connect" ]; then
        START=false
    elif [ "$RESTART" = "Restart" ] || [ "$RESTART" = "Stop" ]; then
        echo "Shutting the container down..."

        docker stop $NAME
        docker rm $NAME

        if [ "$RESTART" = "Stop" ]; then
            exit
        fi
    fi
fi

if [ $START = true ]; then
    if [ -z "$FOLDER_S4C" ]; then
        if [ $DISPLAY ]; then
            FOLDER_S4C=`zenity --file-selection --directory --title "Space 4Clouds Folder"`
        else
            FOLDER_S4C=`dialog --title "Space 4Clouds Folder" --fselect $HOME/ 10 65 3>&1 1>&2 2>&3`
        fi
    fi
    if [ -z "$FOLDER_S4C" ]; then
        exit $FOLDER_NOT_SPECIFIED
    fi

    if [ -z "$FOLDER_MODELIO" ]; then
        if [ $DISPLAY ]; then
            FOLDER_MODELIO=`zenity --file-selection --directory --title "Modelio Creator 4Clouds Folder"`
        else
            FOLDER_MODELIO=`dialog --title "Modelio Creator 4Clouds Folder" --fselect $HOME/ 10 65 3>&1 1>&2 2>&3`
        fi
    fi
    if [ -z "$FOLDER_MODELIO" ]; then
        exit $FOLDER_NOT_SPECIFIED
    fi

    echo "Updating the image..."

    docker pull deibpolimi/modaclouds-designtime

    echo "Starting the container..."

    if [ -z "$GEOMETRY" ]; then
        GEOMETRY=`xrandr --current | grep -m 1 current | awk '{ print $8$9$10 }' | sed 's|,||'`
    fi
    if [ -z "$GEOMETRY" ]; then
        GEOMETRY="1440x900"
    fi

    if [ -z "$VNC_PORT" ] && [ -z "$RDP_PORT" ]; then
        docker run --name $NAME \
        -P \
        -v $FOLDER_S4C:/opt/space4clouds \
        -v $FOLDER_MODELIO:/opt/modelio \
        -e "GEOMETRY=$GEOMETRY" \
        --rm \
        deibpolimi/modaclouds-designtime &
    else
        docker run --name $NAME \
        -p $VNC_PORT:5901 \
        -p $RDP_PORT:3389 \
        -v $FOLDER_S4C:/opt/space4clouds \
        -v $FOLDER_MODELIO:/opt/modelio \
        -e "GEOMETRY=$GEOMETRY" \
        --rm \
        deibpolimi/modaclouds-designtime &
    fi

    sleep 10
fi

if [ -z "$VNC_PORT" ] && [ -z "$RDP_PORT" ]; then
    VNC_PORT=`docker port $NAME 5901 | awk '{ split($1, s, ":"); print s[2]; }'`
    RDP_PORT=`docker port $NAME 3389 | awk '{ split($1, s, ":"); print s[2]; }'`
fi

echo "The port used by VNC is $VNC_PORT, the one used by RDP is $RDP_PORT."

if [ -n "$VNCVIEWER_EXISTS" ]; then
    echo "Connecting via VNC..."

    vncviewer $IP::$VNC_PORT
else
    echo "VNC viewer not found!"
    exit $EXEC_NOT_FOUND
fi
