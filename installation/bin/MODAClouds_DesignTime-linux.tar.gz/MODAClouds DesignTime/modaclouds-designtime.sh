#!/bin/sh

NAME="designtime"

DOCKER_EXISTS=`which docker | grep "/"`
VNCVIEWER_EXISTS=`which vncviewer | grep "/"`

if [ -n ${DOCKER_EXISTS+x} ]; then
    if [[ $DISPLAY ]]; then
        zenity --error --text="Docker is not installed.\nPlease install it before executing this app." --title "MODAClouds DesignTime" --ok-label "Exit"
    else
        dialog --title "MODAClouds DesignTime" --ok-label "Exit" --msgbox "Docker is not installed.\nPlease install it before executing this app." 8 65
    fi
    exit -1000
fi

IP="localhost"

START=true
RUNNING=`docker ps | awk '{print $NF}' | grep $NAME`

if [ -n ${RUNNING+x} ]; then
    if [[ $DISPLAY ]]; then
        RESTART=`zenity --list \
                    --text "The container is already running.\nDo you want to restart it first, or you want to stop it?" \
                    --column="Choose" --column="Action" \
                    "Restart" "Restart" \
                    "Connect" "Connect" \
                    "Stop" "Stop" \
                    --title "MODAClouds DesignTime" --radiolist --cancel-label "Exit"`
    else
        RESTART=`dialog --title "MODAClouds DesignTime" --cancel-label "Exit" --radiolist \
                    "The container is already running.\nDo you want to restart it first, or you want to stop it?" 20 65 3 \
                    "Restart" "" ON \
                    "Connect" "" OFF \
                    "Stop" "" OFF 3>&1 1>&2 2>&3`
    fi

    if [ "$RESTART" = "Connect" ]; then
        START=false
    elif [ "$RESTART" = "Restart" ] || [ "$RESTART" = "Stop" ]; then
        echo "Shutting the container down..."

        docker stop $NAME
        docker rm $NAME

        if [ "$RESTART" = "Stop" ]; then
            exit 0
        fi
    fi
fi

if [ $START = true ]; then
    if [[ $DISPLAY ]]; then
        FOLDER_S4C=`zenity --file-selection --directory --title "Space 4Clouds Folder"`
    else
        FOLDER_S4C=`dialog --title "Space 4Clouds Folder" --fselect $HOME/ 10 65 3>&1 1>&2 2>&3`
    fi
    if [ -z "$FOLDER_S4C" ]; then
        exit -1
    fi

    if [[ $DISPLAY ]]; then
        FOLDER_MODELIO=`zenity --file-selection --directory --title "Modelio Creator 4Clouds Folder"`
    else
        FOLDER_MODELIO=`dialog --title "Modelio Creator 4Clouds Folder" --fselect $HOME/ 10 65 3>&1 1>&2 2>&3`
    fi
    if [ -z "$FOLDER_MODELIO" ]; then
        exit -1
    fi

    exit 0

    echo "Updating the image..."

    docker pull deibpolimi/modaclouds-designtime

    echo "Starting the container..."

    docker run --name $NAME \
    -P \
    -v $FOLDER_S4C:/opt/space4clouds \
    -v $FOLDER_MODELIO:/opt/modelio \
    --rm \
    deibpolimi/modaclouds-designtime &

    sleep 10
fi

VNC_PORT=`docker port $NAME 5901 | awk '{ split($1, s, ":"); print s[2]; }'`
RDP_PORT=`docker port $NAME 3389 | awk '{ split($1, s, ":"); print s[2]; }'`

echo "The port used by VNC is $VNC_PORT, the one used by RDP is $RDP_PORT."

if [ -z ${VNCVIEWER_EXISTS+x} ]; then
    echo "Connecting via VNC..."

    vncviewer $IP::$VNC_PORT
else
    echo "VNC viewer not found!"
    exit -1
fi
