#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

NAME="designtime"

unlink "`xdg-user-dir DESKTOP`/$DESKTOP"
rm "$HOME/.local/share/applications/$DESKTOP"
rm ~/.local/share/applications/$BASH
rm ~/.local/share/icons/hicolor/128x128/apps/$ICON
rm ~/.local/share/icons/hicolor/64x64/apps/$ICON
rm ~/.local/share/icons/hicolor/48x48/apps/$ICON
rm ~/.local/share/icons/hicolor/32x32/apps/$ICON
rm ~/.local/share/icons/hicolor/16x16/apps/$ICON

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

docker rmi `docker images | grep $NAME | awk '{print $3}'`

if [[ $DISPLAY ]]; then
    zenity --question --text="Do you want to uninstall docker?" --title "MODAClouds DesignTime"
    UNINSTALL_IT=$?
else
    dialog --title "MODAClouds DesignTime" --yesno "Do you want to uninstall docker?" 8 65
    UNINSTALL_IT=$?
fi
if [ $UNINSTALL_IT -eq 0 ]; then
    APT_GET_EXISTS=`which apt-get | grep "/"`
    PACMAN_EXISTS=`which pacman | grep "/"`
    if [ -n "$APT_GET_EXISTS" ]; then
        sudo apt-get remove --auto-remove docker
    elif [ -n "$PACMAN_EXISTS" ]; then
        sudo pacman -Rsn docker
    else
        echo "We don't support this operating system at the moment. Please uninstall docker by yourself."
    fi
fi

echo "MODAClouds DesignTime uninstalled!"
