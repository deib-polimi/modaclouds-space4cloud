#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

NAME="designtime"

unlink "`xdg-user-dir DESKTOP`/$DESKTOP"
rm "$HOME/.local/share/applications/$DESKTOP"
rm ~/.local/share/applications/$BASH
rm ~/.local/share/icons/hicolor/128x128/apps/$ICON
rm ~/.local/share/icons/hicolor/64x64/apps/$ICON
rm ~/.local/share/icons/hicolor/48x48/apps/$ICON
rm ~/.local/share/icons/hicolor/32x32/apps/$ICON
rm ~/.local/share/icons/hicolor/16x16/apps/$ICON

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

docker rmi `docker images | grep $NAME | awk '{print $3}'`

echo "MODAClouds DesignTime uninstalled!"
