#!/bin/sh

DESKTOP="MODAClouds DesignTime.desktop"
BASH="modaclouds-designtime.sh"
ICON="modaclouds.png"

NAME="designtime"

XDG_EXISTS=`which xdg-user-dir | grep "/"`
if [ -z "$XDG_EXISTS" ]; then
    APT_GET_EXISTS=`which apt-get | grep "/"`
    PACMAN_EXISTS=`which pacman | grep "/"`
    if [ -n "$APT_GET_EXISTS" ]; then
        sudo apt-get install -y xdg-user-dirs
        DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
    elif [ -n "$PACMAN_EXISTS" ]; then
        sudo pacman -S xdg-user-dirs
        DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
    else
        DESKTOP_FOLDER="$HOME/Desktop/"
    fi
else
    DESKTOP_FOLDER=`xdg-user-dir DESKTOP`/
fi
if [ ! -d "$DESKTOP_FOLDER" ]; then
    DESKTOP_FOLDER=$HOME
fi

unlink "$DESKTOP_FOLDER$DESKTOP"
rm "$HOME/.local/share/applications/$DESKTOP"
rm ~/.local/share/applications/$BASH
rm ~/.local/share/icons/hicolor/128x128/apps/$ICON
rm ~/.local/share/icons/hicolor/64x64/apps/$ICON
rm ~/.local/share/icons/hicolor/48x48/apps/$ICON
rm ~/.local/share/icons/hicolor/32x32/apps/$ICON
rm ~/.local/share/icons/hicolor/16x16/apps/$ICON

sudo update-desktop-database
sudo gtk-update-icon-cache -f /usr/share/icons/hicolor

docker rmi `docker images | grep $NAME | awk '{print $3}'`

APT_GET_EXISTS=`which apt-get | grep "/"`
PACMAN_EXISTS=`which pacman | grep "/"`

if [ $DISPLAY ]; then
    ASKER_EXISTS=`which zenity | grep "/"`
    if [ -z "$ASKER_EXISTS" ]; then
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y zenity
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S zenity
        fi
    fi
else
    ASKER_EXISTS=`which dialog | grep "/"`
    if [ -z "$ASKER_EXISTS" ]; then
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get update
            sudo apt-get install -y dialog
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Sy
            sudo pacman -S dialog
        fi
    fi
fi

if [ -z "$ASKER_EXISTS" ]; then
    if [ $DISPLAY ]; then
        zenity --question --text="Do you want to uninstall docker?" --title "MODAClouds DesignTime"
        UNINSTALL_IT=$?
    else
        dialog --title "MODAClouds DesignTime" --yesno "Do you want to uninstall docker?" 8 65
        UNINSTALL_IT=$?
    fi
    if [ $UNINSTALL_IT -eq 0 ]; then
        if [ -n "$APT_GET_EXISTS" ]; then
            sudo apt-get remove --auto-remove docker
        elif [ -n "$PACMAN_EXISTS" ]; then
            sudo pacman -Rsn docker
        else
            echo "We don't support this operating system at the moment. Please uninstall docker by yourself."
        fi
    fi
fi

echo "MODAClouds DesignTime uninstalled!"
